<?php 
$con=mysqli_connect('localhost','root','','dbms');
if(mysqli_connect_errno($con))
{
	die("Connection error");
 }
 ?>
